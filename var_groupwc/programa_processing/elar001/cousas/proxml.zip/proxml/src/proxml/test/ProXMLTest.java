package proxml.test;

import proxml.XMLElement;


public class ProXMLTest{
	
	private void testProXml(){
		//XMLElement element = XMLElement.loadElementFrom(this.getClass().getResource("pro.xml"));
	}

	/**
	 * @param args
	 */
	public static void main(String[] args){
		new ProXMLTest().testProXml();
	}

}
